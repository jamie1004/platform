package hyunmyungsoo.petmeet.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Like {
	private int likeNum;
	private int sitterNum;
	private String userId;
}